# MouseSideKey

讓滑鼠側邊按鍵擁有視窗管理功能，基於 [Hammerspoon](https://www.hammerspoon.org/) 實作。
支援 USB、2.4G 無線、藍牙等各種滑鼠，可同時設定多隻滑鼠。

---

## 功能

| 按鍵 | 功能 |
|------|------|
| 上方側鍵 | 視窗最大化 / 復原（切換） |
| 下方側鍵 | 將視窗移到另一個螢幕 |

---

## 安裝步驟

1. 在 Finder 中找到 `install.command`
2. **雙擊**執行（若出現「無法開啟」請右鍵 → 開啟）
3. 安裝程式會自動完成以下事項：
   - 安裝 Homebrew（若尚未安裝）
   - 安裝 Hammerspoon
   - 寫入設定檔
   - 設定**開機自動啟動**
4. 給予輔助使用權限：
   - 系統設定 → 隱私權與安全性 → 輔助使用 → 勾選 Hammerspoon
5. 點選選單列 Hammerspoon → **Reload Config**

> 完成後每次開機側鍵功能自動生效，無需手動操作。

---

## 新增滑鼠（學習模式）

安裝完成後，若要讓其他滑鼠也能使用側鍵功能：

1. 確認 Hammerspoon 已啟動（選單列有圖示）
2. 按下 `⌘⇧⌥L`，畫面出現「學習模式 (1/2)」
3. 用**新滑鼠**按上方側鍵
4. 出現「(2/2)」後，按下方側鍵
5. 出現「設定完成！」即可

設定會自動儲存，重開機後依然有效。

---

## 支援的事件類型

| 事件類型 | 適用情境 |
|----------|----------|
| `otherMouseDown` | USB / 2.4G 無線滑鼠（Razer 等） |
| `keyDown` | 部分藍牙滑鼠（側鍵偽裝成鍵盤事件） |

學習模式會自動偵測並記錄事件類型、`keyboardType`、**CGEvent flags** 三個欄位，確保不同裝置可精確區分。

### 裝置識別邏輯（三層比對）

| 欄位 | 說明 |
|------|------|
| `keyboardType` | 區分藍牙 HID 滑鼠與一般鍵盤（數值不同） |
| `CGEvent flags` | 同 keyCode + 同 keyboardType 時，以此最終區分裝置 |

> **為何需要 flags？**
> DFM80 BT 藍牙滑鼠與某些 USB 自定義鍵盤可能送出相同的 keyCode（如 `124` = 向右鍵）且 keyboardType 相同，此時只有 CGEvent flags 值不同（DFM80 BT 為 `11665674`，一般鍵盤為 `10486016`），才能精確識別來源裝置。

---

## 設定檔位置

| 檔案 | 說明 |
|------|------|
| `~/.hammerspoon/init.lua` | Hammerspoon 主設定 |
| `~/.hammerspoon/mouse_side_keys.json` | 學習模式儲存的按鍵對應 |

---

## 系統需求

- macOS 12 以上
- [Hammerspoon](https://www.hammerspoon.org/)（安裝程式會自動處理）

---

## 測試過的滑鼠

| 滑鼠 | 介面 | 事件類型 | keyboardType | flags |
|------|------|----------|-------------|-------|
| Razer Viper Mini | USB | `otherMouseDown` button 3/4 | — | — |
| darkFlash DFM80 BT | 藍牙 | `keyDown` keyCode 126（上/最大化）、124（下/移螢幕） | 40 | 11665674（上）/ 依按鍵而異 |

> 以上兩隻滑鼠的對應已內建於 `mouse_side_keys.sample.json`，
> `install.command` 安裝時會自動帶入（不覆蓋既有設定）。
> 範本未帶 flags 欄位（比對時忽略該層）；若遇自定義鍵盤誤觸，以 `⌘⇧⌥L` 重新學習即自動補上精確 flags。

---

## 已知問題與解決方式

### 自定義 USB 鍵盤按鍵誤觸側鍵功能

**現象**：自定義 USB 鍵盤某按鍵（如向右鍵）按下後，觸發了移螢幕功能。

**原因**：該鍵盤與藍牙滑鼠送出相同的 keyCode 及 keyboardType，舊版僅靠這兩個欄位區分，無法判斷來源裝置。

**解法**（已內建於 v2 版）：
1. 執行 `diagnose_key_source.lua`（貼入 Hammerspoon Console）依序按兩個裝置的同一個鍵
2. 比對 `CGEventData.flags` 值，找出差異
3. 以 `⌘⇧⌥L` 重新學習藍牙滑鼠側鍵，新設定會自動帶入 flags 值
4. 之後分派比對時，config 有 flags 欄位則精確吻合，無 flags 則向下相容忽略

---

## 檔案說明

```
MouseSideKey/
├── install.command          # 安裝程式（雙擊執行）
├── init.lua                 # Hammerspoon 設定檔
├── detect_all_events.lua    # 全事件偵測工具（找出藍牙滑鼠事件類型）
├── detect_buttons.lua       # 滑鼠按鍵偵測工具
├── diagnose_key_source.lua  # 裝置來源診斷工具（比較兩裝置全屬性）
└── 說明.md                  # 本文件
```

---

## 解除安裝

```bash
# 移除設定檔
rm ~/.hammerspoon/init.lua
rm -f ~/.hammerspoon/mouse_side_keys.json

# 移除開機自動啟動
osascript -e 'tell application "System Events" to delete login item "Hammerspoon"'

# 移除 Hammerspoon
brew uninstall --cask hammerspoon
```

> 若安裝前有舊設定，備份檔在 `~/.hammerspoon/init.lua.backup`。
