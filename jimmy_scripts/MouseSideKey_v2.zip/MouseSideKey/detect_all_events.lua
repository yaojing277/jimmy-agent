-- 全事件偵測腳本：找出藍牙滑鼠側鍵的真實事件類型
-- 結果會寫入 /tmp/mouse_detect.log

local logFile = "/tmp/mouse_detect.log"
local f = io.open(logFile, "w")
f:write("偵測開始，請按 DFM80 BT 的側邊鍵\n")
f:close()

local function log(msg)
    local f2 = io.open(logFile, "a")
    f2:write(msg .. "\n")
    f2:close()
    print(msg)
end

_detectWatchers = {}

-- 監聽所有滑鼠相關事件
local mouseEvents = {
    hs.eventtap.event.types.otherMouseDown,
    hs.eventtap.event.types.otherMouseUp,
    hs.eventtap.event.types.leftMouseDown,
    hs.eventtap.event.types.rightMouseDown,
    hs.eventtap.event.types.scrollWheel,
}

_detectWatchers[1] = hs.eventtap.new(mouseEvents, function(event)
    local t = event:getType()
    local button = event:getProperty(hs.eventtap.event.properties.mouseEventButtonNumber)
    local msg = string.format("[MOUSE] type=%d, button=%d", t, button)
    log(msg)
    if button >= 3 then
        hs.alert.show("MOUSE button=" .. button .. " type=" .. t, 3)
    end
    return false
end)

-- 監聽所有鍵盤事件（部分藍牙滑鼠側鍵會偽裝成按鍵）
_detectWatchers[2] = hs.eventtap.new(
    { hs.eventtap.event.types.keyDown },
    function(event)
        local code = event:getKeyCode()
        local flags = event:getFlags()
        local msg = string.format("[KEY] keyCode=%d, flags=%s", code, hs.inspect(flags))
        log(msg)
        -- 只 alert 特殊按鍵（非一般字母）
        if code > 100 or (code >= 0 and code <= 5) then
            hs.alert.show("KEY code=" .. code, 3)
        end
        return false
    end
)

-- 監聽 systemKey 事件（媒體鍵、瀏覽器按鍵等）
_detectWatchers[3] = hs.eventtap.new(
    { hs.eventtap.event.types.systemDefined },
    function(event)
        local data = event:systemKey()
        local msg = string.format("[SYSTEM] %s", hs.inspect(data))
        log(msg)
        hs.alert.show("SYSTEM: " .. hs.inspect(data), 3)
        return false
    end
)

for _, w in ipairs(_detectWatchers) do
    w:start()
end

hs.alert.show("全事件偵測已啟動\n請按 DFM80 BT 側邊鍵", 5)
log("偵測器已啟動，等待按鍵...")
