-- 診斷腳本：比較兩個裝置的 keyCode=124 事件所有屬性
-- 使用方式：貼到 Hammerspoon Console 執行，依序按 DFM80 BT 側鍵 和 USB 鍵盤向右鍵

local logPath = "/tmp/key_diag.log"
io.open(logPath, "w"):write("=== 按鍵屬性偵測開始 ===\n"):close()
local pressCount = 0

local p = hs.eventtap.event.properties

_diagWatcher = hs.eventtap.new(
    {hs.eventtap.event.types.keyDown},
    function(event)
        local code = event:getKeyCode()
        if code ~= 124 then return false end

        pressCount = pressCount + 1
        local label = pressCount == 1 and "【第1次：DFM80 BT 側鍵】" or ("【第" .. pressCount .. "次】")

        local lines = {label}
        for name, val in pairs(p) do
            local ok, result = pcall(function() return event:getProperty(val) end)
            if ok then
                lines[#lines+1] = string.format("  %-45s (%3d) = %s", name, val, tostring(result))
            end
        end

        -- 嘗試取得 raw data
        local ok2, raw = pcall(function() return event:getRawEventData() end)
        if ok2 and raw then
            lines[#lines+1] = "  [rawEventData] = " .. hs.inspect(raw)
        end

        local out = table.concat(lines, "\n")
        local f = io.open(logPath, "a")
        f:write(out .. "\n" .. string.rep("-", 60) .. "\n")
        f:close()

        hs.alert.show(label .. "\n已記錄到 /tmp/key_diag.log", 3)
        print(out)
        return false
    end
)

_diagWatcher:start()
hs.alert.show("偵測已啟動\n請按：\n1. DFM80 BT 側鍵\n2. USB 鍵盤向右鍵", 6)
print("偵測已啟動，請依序按兩個鍵，結果存於 /tmp/key_diag.log")
