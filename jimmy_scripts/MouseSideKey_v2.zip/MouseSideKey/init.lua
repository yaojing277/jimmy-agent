-- 滑鼠側鍵設定（多滑鼠 + 多事件類型）
-- 預設支援 Razer Viper Mini (USB otherMouseDown button 3/4)
-- 藍牙滑鼠：按 ⌘⇧⌥L 進入學習模式，按兩下側鍵即完成設定
-- 支援兩種事件類型：otherMouseDown / keyDown（含 keyboardType + flags 區分來源）

local configFile = os.getenv("HOME") .. "/.hammerspoon/mouse_side_keys.json"

local config = {
    maximize   = {{eType = "mouse", button = 4}},
    moveScreen = {{eType = "mouse", button = 3}}
}

-- ── 工具函數 ────────────────────────────────────────────

-- 產生唯一識別字串（含 flags），用於學習模式去重
local function sigKey(sig)
    if sig.eType == "mouse" then return "mouse:" .. sig.button end
    if sig.eType == "key" then
        local base = "key:" .. sig.keyCode
        if sig.keyboardType ~= nil then
            base = base .. ":" .. tostring(sig.keyboardType)
        end
        if sig.flags ~= nil then
            base = base .. ":f" .. tostring(sig.flags)
        end
        return base
    end
    return "unknown"
end

-- 學習模式去重：完全一致（含 flags）才視為重複
local function sigExistsExact(list, sig)
    local k = sigKey(sig)
    for _, s in ipairs(list) do
        if sigKey(s) == k then return true end
    end
    return false
end

-- 分派比對：config 若有 flags 欄位則需精確吻合，無則忽略（向下相容）
local function sigMatches(list, sig)
    for _, s in ipairs(list) do
        if s.eType == sig.eType then
            if s.eType == "mouse" and s.button == sig.button then
                return true
            elseif s.eType == "key" and s.keyCode == sig.keyCode then
                local ktOk = s.keyboardType == nil or s.keyboardType == sig.keyboardType
                local flOk = s.flags == nil or s.flags == sig.flags
                if ktOk and flOk then return true end
            end
        end
    end
    return false
end

local function saveConfig()
    local f = io.open(configFile, "w")
    if f then f:write(hs.json.encode(config)); f:close() end
end

local function loadConfig()
    local f = io.open(configFile, "r")
    if not f then return end
    local loaded = hs.json.decode(f:read("*all"))
    f:close()
    if loaded then config = loaded end
end

-- ── 視窗操作 ────────────────────────────────────────────
windowPreviousFrames = {}

local function toggleMaximize(win)
    local id = win:id()
    local maxF = win:screen():frame()
    local cur  = win:frame()
    local isMax = (cur.x == maxF.x and cur.y == maxF.y and
                   cur.w == maxF.w and cur.h == maxF.h)
    if isMax and windowPreviousFrames[id] then
        win:setFrame(windowPreviousFrames[id])
        windowPreviousFrames[id] = nil
    else
        windowPreviousFrames[id] = cur
        win:maximize()
    end
end

local function moveToNextScreen(win)
    local screens = hs.screen.allScreens()
    local cur, next = win:screen()
    for i, s in ipairs(screens) do
        if s == cur then next = screens[(i % #screens) + 1]; break end
    end
    if next then
        win:moveToScreen(next, true, true)
        hs.alert.show("視窗已移至 " .. next:name())
    end
end

-- ── 學習模式 ────────────────────────────────────────────
local learnMode = false
local learnStep = 0

local function startLearnMode()
    learnMode = true
    learnStep = 1
    hs.alert.show("學習模式 (1/2)\n請按「最大化」功能的側邊鍵", 8)
end

-- ── 核心分派 ────────────────────────────────────────────
local function dispatch(sig)
    if learnMode then
        if learnStep == 1 then
            if not sigExistsExact(config.maximize, sig) then
                table.insert(config.maximize, sig)
            end
            learnStep = 2
            hs.alert.show("✓ 已記錄！(2/2)\n請按「移到另一個螢幕」的側邊鍵", 8)
        elseif learnStep == 2 then
            if not sigExistsExact(config.moveScreen, sig) then
                table.insert(config.moveScreen, sig)
            end
            learnMode = false
            learnStep = 0
            saveConfig()
            hs.alert.show("✓ 設定完成！\n兩隻滑鼠側鍵現在都可以使用了", 4)
        end
        return true
    end

    local win = hs.window.focusedWindow()
    if not win then return false end

    if sigMatches(config.maximize, sig) then
        toggleMaximize(win); return true
    end
    if sigMatches(config.moveScreen, sig) then
        moveToNextScreen(win); return true
    end
    return false
end

-- ── 事件監聽器 1：otherMouseDown（USB / 2.4G 接收器）────
_mouseWatcher = hs.eventtap.new(
    {hs.eventtap.event.types.otherMouseDown},
    function(event)
        local btn = event:getProperty(hs.eventtap.event.properties.mouseEventButtonNumber)
        if btn < 3 then return false end
        return dispatch({eType = "mouse", button = btn})
    end
)

-- ── 事件監聽器 2：keyDown（部分藍牙滑鼠側鍵偽裝成按鍵）──
_keyWatcher = hs.eventtap.new(
    {hs.eventtap.event.types.keyDown},
    function(event)
        local code = event:getKeyCode()
        if learnMode and code < 53 then return false end
        local kt = event:getProperty(hs.eventtap.event.properties.keyboardEventKeyboardType)
        -- 捕捉 CGEvent flags，用於精確區分不同裝置（同 keyCode 但 flags 不同）
        local raw = event:getRawEventData()
        local eflags = raw and raw.CGEventData and raw.CGEventData.flags
        local sig = {eType = "key", keyCode = code, keyboardType = kt, flags = eflags}
        if not learnMode and not sigMatches(config.maximize, sig)
                         and not sigMatches(config.moveScreen, sig) then
            return false
        end
        return dispatch(sig)
    end
)

-- ── 啟動 ────────────────────────────────────────────────
loadConfig()
_mouseWatcher:start()
_keyWatcher:start()

-- 監聽 JSON 設定檔變更，自動 reload（免手動）
_configWatcher = hs.pathwatcher.new(configFile, function()
    loadConfig()
    hs.alert.show("側鍵設定已重新載入 ✓", 2)
end):start()

hs.hotkey.bind({"cmd", "shift", "alt"}, "L", startLearnMode)
hs.alert.show("Hammerspoon 已載入 ✓\n按 ⌘⇧⌥L 重新設定 DFM80 BT 側鍵")
