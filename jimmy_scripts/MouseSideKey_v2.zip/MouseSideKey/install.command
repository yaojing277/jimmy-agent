#!/bin/bash
# MouseSideKey 安裝程式
# 功能：滑鼠側鍵上方=視窗最大化切換，下方=移到另一個螢幕

set -e

echo ""
echo "======================================"
echo "  MouseSideKey 安裝程式"
echo "======================================"
echo ""

# 1. 確認 Homebrew
if ! command -v brew &>/dev/null; then
    echo ">>> 安裝 Homebrew..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
else
    echo "✓ Homebrew 已安裝"
fi

# 2. 確認 Hammerspoon
if [ ! -d "/Applications/Hammerspoon.app" ]; then
    echo ">>> 安裝 Hammerspoon..."
    brew install --cask hammerspoon
else
    echo "✓ Hammerspoon 已安裝"
fi

# 3. 備份舊設定
mkdir -p ~/.hammerspoon
if [ -f ~/.hammerspoon/init.lua ]; then
    cp ~/.hammerspoon/init.lua ~/.hammerspoon/init.lua.backup
    echo "✓ 舊設定已備份至 ~/.hammerspoon/init.lua.backup"
fi

# 4. 複製設定檔
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
cp "$SCRIPT_DIR/init.lua" ~/.hammerspoon/init.lua
echo "✓ 設定檔已安裝至 ~/.hammerspoon/init.lua"

# 4b. 帶入已知滑鼠的按鍵對應範本（已有設定則不覆蓋，保留學習結果）
if [ -f "$SCRIPT_DIR/mouse_side_keys.sample.json" ] && [ ! -f ~/.hammerspoon/mouse_side_keys.json ]; then
    cp "$SCRIPT_DIR/mouse_side_keys.sample.json" ~/.hammerspoon/mouse_side_keys.json
    echo "✓ 已帶入按鍵對應範本（Razer Viper Mini + DFM80 BT）"
fi

# 5. 加入登入項目（開機自動啟動）
osascript -e 'tell application "System Events" to make login item at end with properties {path:"/Applications/Hammerspoon.app", hidden:false}' 2>/dev/null \
    && echo "✓ 已設定開機自動啟動" \
    || echo "⚠ 自動啟動設定失敗，請手動至「系統設定 → 一般 → 登入項目」加入 Hammerspoon"

# 6. 啟動 Hammerspoon
open -a Hammerspoon
sleep 2

echo ""
echo "======================================"
echo "  安裝完成！"
echo "======================================"
echo ""
echo "請完成以下步驟："
echo ""
echo "  1. macOS 會詢問輔助使用權限"
echo "     → 系統設定 → 隱私權與安全性 → 輔助使用"
echo "     → 勾選 Hammerspoon"
echo ""
echo "  2. 點選選單列的 Hammerspoon 圖示"
echo "     → 選 Reload Config"
echo ""
echo "  完成後即可使用側鍵功能："
echo "  　上方側鍵 = 視窗最大化 / 復原"
echo "  　下方側鍵 = 視窗移到另一個螢幕"
echo ""
read -p "按 Enter 關閉..."
