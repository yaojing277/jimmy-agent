-- 暫時偵測腳本：顯示所有滑鼠按鍵編號
-- 使用方式：貼到 Hammerspoon Console 執行，然後按滑鼠各個按鍵
-- 看到 alert 顯示的數字就是該按鍵的 button 編號

_detectWatcher = hs.eventtap.new(
    { hs.eventtap.event.types.otherMouseDown },
    function(event)
        local button = event:getProperty(
            hs.eventtap.event.properties.mouseEventButtonNumber
        )
        hs.alert.show("按鍵編號：" .. button, 2)
        print("Button number: " .. button)
        return false  -- 不攔截，讓原本行為繼續
    end
)
_detectWatcher:start()
hs.alert.show("偵測模式啟動 - 請按側邊鍵", 3)
print("偵測模式已啟動，按側邊鍵後看 Console 輸出的數字")
